import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
const routes: Routes = [
  {
    path: 'login',
    loadChildren: () =>
      import(`../app/authentication/login.module`).then((m) => m.LoginModule),
  },
  {
    path: 'main',
    loadChildren: () => import(`./main/main.module`).then((m) => m.MainModule),
  },
  { path: '', redirectTo: 'login', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { enableTracing: false })],
  exports: [RouterModule],
})
export class AppRoutingModule {}
