import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth-service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;

  year = new Date().getFullYear();
  constructor(
    public router: Router,
    private snackbar: MatSnackBar,
    private formBuilder: FormBuilder,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.email]],
      password: ['', [Validators.minLength(6)]],
      rememberMe: false,
    });
  }

  onSubmit() {
    if (this.loginForm.valid) {
      const isLoggedIn = this.authService.login(
        this.loginForm.get('email')?.value,
        this.loginForm.get('password')?.value
      );

      if (isLoggedIn) {
        console.log('Login successful');
        this.router.navigate(['/main/home']);
        // Redirect or perform necessary actions upon successful login
      } else {
        this.openSnackBar('LogIn Failed', 'Done');
        console.log('Login failed');
        // Display error message or perform necessary actions upon failed login
      }
    }
  }

  signUp() {
    this.router.navigate(['/signup']);
  }

  disableValidator() {
    if (
      this.loginForm.get('email')?.value == '' ||
      this.loginForm.get('password')?.value == ''
    ) {
      return true;
    } else {
      return false;
    }
  }

  openSnackBar(message: string, action: string) {
    this.snackbar.open(message, action, { duration: 3000 });
  }
}
