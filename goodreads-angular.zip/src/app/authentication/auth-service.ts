import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { map, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor() {}

  login(username: string, password: string): boolean {
    let user: any = {
      username: username,
      password: password,
      email: username,
    };

    // Retrieve existing items from Local Storage
    const existingItems = this.getItems('userData');

    // Check if the value already exists in the array
    return existingItems.some((item) => this.isLogin(item, user));
  }

  // Check if two objects are equal
  private isLogin(obj1: any, obj2: any): boolean {
    let value1 = JSON.parse(obj1);
    if (value1.email == obj2.email && value1.password == obj2.password) {
      console.log(value1);
      localStorage.setItem('username', value1.username);
      return true;
    } else {
      return false;
    }
  }

  // Add item to Local Storage
  addItem(key: string, value: any): boolean {
    // Retrieve existing items from Local Storage
    const existingItems = this.getItems(key);

    // Check if the value already exists in the array
    const exists = existingItems.some((item) => this.isEqual(item, value));
    // If the value does not already exist, add it to the array
    if (!exists) {
      existingItems.push(JSON.stringify(value));
      localStorage.setItem(key, JSON.stringify(existingItems));
    }
    return !exists;
  }

  // Check if two objects are equal
  private isEqual(obj1: any, obj2: any): boolean {
    let value1 = JSON.parse(obj1);
    if (value1.email == obj2.email) {
      return true;
    } else {
      return false;
    }
  }

  // Retrieve items under a specific key from Local Storage
  getItems(key: string): any[] {
    const itemsString = localStorage.getItem(key);
    return itemsString ? JSON.parse(itemsString) : [];
  }

  // Clear all items from Local Storage
  clear(): void {
    localStorage.clear();
  }
}
