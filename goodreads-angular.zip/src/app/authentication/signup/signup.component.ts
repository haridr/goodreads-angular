import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth-service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss'],
})
export class SignupComponent implements OnInit {
  signupform!: FormGroup;
  year = new Date().getFullYear();

  constructor(
    private snackbar: MatSnackBar,
    public router: Router,
    private formBuilder: FormBuilder,
    public authService: AuthService
  ) {}

  ngOnInit() {
    this.signupform = this.formBuilder.group(
      {
        username: [''],
        email: ['', [Validators.email]],
        password: ['', [Validators.minLength(6)]],
        reenterpassword: ['', [Validators.minLength(6)]],
        rememberMe: false,
      },
      {
        validator: passwordConfirmationValidator('password', 'reenterpassword'),
      }
    );
  }

  disableValidator() {
    if (
      this.signupform.get('username')?.value === '' ||
      this.signupform.get('email')?.value == '' ||
      this.signupform.get('password')?.value == '' ||
      this.signupform.get('reenterpassword')?.value == ''
    ) {
      return true;
    } else {
      return false;
    }
  }

  // checkPasswords() {
  //   if (this.signupform.get('reenterpassword')?.dirty) {
  //     const password = this.signupform.get('password')?.value;
  //     const confirmPassword = this.signupform.get('reenterpassword')?.value;

  //     return password === confirmPassword ? null : { notSame: true };
  //   } else {
  //     return { notSame: false };
  //   }
  // }

  onSubmit() {
    if (this.signupform.valid) {
      // Perform registration logic here

      let user: any = {
        username: this.signupform.get('username')?.value,
        password: this.signupform.get('password')?.value,
        email: this.signupform.get('email')?.value,
      };

      const signUp = this.authService.addItem('userData', user);
      console.log('signUp', signUp);
      if (signUp) {
        this.openSnackBar(
          'Account Created Successfully, Please Login Valid Credentials',
          'Done!'
        );
        this.router.navigate(['/login']);
      }
    }
  }

  openSnackBar(message: string, action: string) {
    this.snackbar.open(message, action, { duration: 3000 });
  }
}

import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export function passwordConfirmationValidator(
  controlName: string,
  matchingControlName: string
): ValidatorFn {
  return (formGroup: AbstractControl): ValidationErrors | null => {
    const passwordControl = formGroup.get(controlName);
    const confirmPasswordControl = formGroup.get(matchingControlName);

    if (!passwordControl || !confirmPasswordControl) {
      return null;
    }

    if (passwordControl.value !== confirmPasswordControl.value) {
      confirmPasswordControl.setErrors({ passwordMismatch: true });
    } else {
      confirmPasswordControl.setErrors(null);
    }

    return null;
  };
}
