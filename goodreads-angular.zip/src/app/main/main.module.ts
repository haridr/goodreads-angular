import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { MainRoutingModule } from './main-routing.module';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './components/home/home.component';
import { MybooksComponent } from './components/mybooks/MybooksComponent';
import { BookviewComponent } from './components/bookview/bookview.component';

@NgModule({
  declarations: [
    LandingPageComponent,
    FooterComponent,
    HeaderComponent,
    HomeComponent,
    MybooksComponent,
    BookviewComponent,
  ],
  imports: [SharedModule, MainRoutingModule],
})
export class MainModule {}
