import { Component, OnInit } from '@angular/core';
import { mainService } from '../../main-service';

@Component({
  selector: 'app-bookview',
  templateUrl: './bookview.component.html',
  styleUrls: ['./bookview.component.scss'],
})
export class BookviewComponent implements OnInit {
  // bookData: any = {
  //   booktitle: 'Trending this week in one of your favorite genres',
  //   link: 'https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1697984764i/199551453._SY180_.jpg',
  //   genere: 'Thriller',
  //   bookName: 'The Wrong Daughter',
  //   bookAuthor: 'Dandy Smith',
  //   details:
  //     "The phone starts vibrating in my hand. It's my father. He never calls. Pulse racing in trepidation, I sit up in bed and answer. 'Caitlin,' he says. 'You need to come to the house. Right now. It's Olivia. She's back. On the night when Caitlin and Olivia's parents leave them to go to a dinner party both girls are full of excitement about being old enough to stay home alone What they don't see is the figure watching them through the open window. Who, after the girls have fallen asleep, will turn the handle of the unlocked back door. When their parents return, they will find Olivia's bed empty. Their eldest daughter gone. Never to return. Until now. But is the woman who claims to be Olivia really all she seems? And is everything Caitlin said she saw that night really the whole truth? Their family have dreamt of this moment. But could Olivia's return be what destroys them.The absolutely gripping and page-turning new psychological thriller from bestselling author Dandy Smith, with a killer twist you won't see coming.",
  // };

  bookData: any;

  constructor(private mainservice: mainService) {
    this.mainservice.currentMessage.subscribe((e) => {
      if (e != null) {
        this.bookData = e;
        console.log('bookdata', this.bookData);
      }
    });
  }

  ngOnInit(): void {
    console.log();
  }
}
