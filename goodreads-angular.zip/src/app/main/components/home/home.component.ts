import { Component, HostListener, OnInit } from '@angular/core';
import { bookData } from '../books-file';
import { Router } from '@angular/router';
import { mainService } from '../../main-service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  wantToRead = 1;
  currentlyReading = 1;
  read = 0;
  public innerWidth: any;
  display = 'desktop';
  searchEnabled: boolean = false;
  openableMenu = false;

  bookMockDate = bookData;
  mainList = <any>[];

  constructor(private router: Router, private mainservice: mainService) {
    let data: any = localStorage.getItem('bookdata');
    let books = JSON.parse(data);

    console.log(books);

    if (books != null && books.length > 0) {
      books.forEach((element: any) => {
        let b = JSON.parse(element);
        if (b.wantToRead === true) {
          this.wantToRead = this.wantToRead + 1;
        }

        if (b.currentRead === true) {
          this.currentlyReading = this.currentlyReading + 1;
        }
        if (b.read === true) {
          this.read = this.read + 1;
        }

        this.mainList.push(b);
      });
      // this.bookMockDate = this.bookMockDate.concat(this.mainList);
      this.bookMockDate = this.mergeAndRemoveDuplicates(
        this.bookMockDate,
        this.mainList
      );
      console.log(this.bookMockDate);
    }
  }

  mergeAndRemoveDuplicates(json1: any[], json2: any[]): any[] {
    json2.forEach((item2) => {
      const index = json1.findIndex(
        (item1) => item1.bookName === item2.bookName
      );
      if (index !== -1) {
        json1[index].wantToRead = item2.wantToRead;
        json1[index].currentRead = item2.currentRead;
        json1[index].read = item2.read;
      }
    });
    return json1;
  }

  ngOnInit(): void {
    //for screen size
    this.onResize();
  }

  @HostListener('window:resize', ['$event'])
  onResize() {
    this.innerWidth = window.innerWidth;

    if (this.innerWidth < 1200 && this.innerWidth > 767) {
      this.display = 'tablet';
      this.searchEnabled = false;
    } else if (this.innerWidth < 767) {
      this.display = 'mobile';
    } else {
      this.display = 'desktop';
      this.searchEnabled = false;
    }

    console.log(this.display);
  }

  bookClick(book: any, type: string) {
    book[type] = true;

    // Add item to Local Storage
    // Retrieve existing items from Local Storage
    const existingItems = this.getItems('bookdata');

    // Check if the value already exists in the array
    const exists = existingItems.some((item) => this.isEqual(item, book));
    // If the value does not already exist, add it to the array
    if (!exists) {
      existingItems.push(JSON.stringify(book));
      localStorage.setItem('bookdata', JSON.stringify(existingItems));
    }

    console.log('book', book);

    return book;
  }

  // Retrieve items under a specific key from Local Storage
  getItems(key: string): any[] {
    const itemsString = localStorage.getItem(key);
    return itemsString ? JSON.parse(itemsString) : [];
  }

  // Check if two objects are equal
  private isEqual(obj1: any, obj2: any): boolean {
    let value1 = JSON.parse(obj1);
    if (value1.bookName == obj2.bookName) {
      return true;
    } else {
      return false;
    }
  }

  booknavigate(book: any) {
    this.mainservice.sendMessage(book);
    this.router.navigate(['/main/bookview']);
  }
}
