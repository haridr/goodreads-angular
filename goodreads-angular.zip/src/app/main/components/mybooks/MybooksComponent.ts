import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { mainService } from '../../main-service';

@Component({
  selector: 'app-mybooks',
  templateUrl: './mybooks.component.html',
  styleUrls: ['./mybooks.component.scss'],
})
export class MybooksComponent implements OnInit {
  mainList: any = [];
  bookMockData: any = [];

  wantToRead = 0;
  currentlyReading = 0;
  read = 0;

  constructor(private router: Router, private mainservice: mainService) {
    let data: any = localStorage.getItem('bookdata');
    let books = JSON.parse(data);

    console.log(books);

    if (books != null && books.length > 0) {
      books.forEach((element: any) => {
        let b = JSON.parse(element);
        if (b.wantToRead === true) {
          this.wantToRead = this.wantToRead + 1;
        }

        if (b.currentRead === true) {
          this.currentlyReading = this.currentlyReading + 1;
        }
        if (b.read === true) {
          this.read = this.read + 1;
        }

        this.mainList.push(b);
        this.bookMockData = this.mainList;
      });
    }
  }

  filterValues(type: string) {
    this.bookMockData = [];
    console.log('type', type);
    if (type === 'all') {
      this.bookMockData = this.mainList;
    } else {
      this.bookMockData = this.mainList.filter((e: any) => e[type] === true);
    }
  }

  ngOnInit(): void {}

  booknavigate(book: any) {
    setTimeout(() => {
      this.mainservice.sendMessage(book);
      this.router.navigate(['/main/bookview']);
    }, 100);
  }
}
