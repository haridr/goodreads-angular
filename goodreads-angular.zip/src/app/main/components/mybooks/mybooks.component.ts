import { Component, OnInit } from '@angular/core';
import { bookData } from '../books-file';
import { Router } from '@angular/router';
import { mainService } from '../../main-service';

@Component({
  selector: 'app-mybooks',
  templateUrl: './mybooks.component.html',
  styleUrls: ['./mybooks.component.scss'],
})
export class MybooksComponent implements OnInit {
  bookMockData: any;

  constructor(private router: Router, private mainservice: mainService) {
    let data: any = localStorage.getItem('bookdata');
    let books = JSON.parse(data);
    this.bookMockData = books.forEach((element: any) => JSON.parse(element));

    console.log(this.bookMockData);
  }

  ngOnInit(): void {}

  booknavigate(book: any) {
    setTimeout(() => {
      this.mainservice.sendMessage(book);
      this.router.navigate(['/main/bookview']);
    }, 2000);
  }
}
