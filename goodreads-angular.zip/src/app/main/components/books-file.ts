export interface Book {
  booktitle: string;
  link: string;
  bookName: string;
  genere: string;
  bookAuthor: string;
  details: string;
}

export const bookData = [
  {
    booktitle: 'Trending this week in one of your favorite genres',
    link: 'https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1697984764i/199551453._SY180_.jpg',
    genere: 'Thriller',
    bookName: 'The Wrong Daughter',
    bookAuthor: 'Dandy Smith',
    wantToRead: false,
    currentRead: false,
    read: false,
    details:
      "The phone starts vibrating in my hand. It's my father. He never calls. Pulse racing in trepidation, I sit up in bed and answer. 'Caitlin,' he says. 'You need to come to the house. Right now. It's Olivia. She's back. On the night when Caitlin and Olivia's parents leave them to go to a dinner party both girls are full of excitement about being old enough to stay home alone What they don't see is the figure watching them through the open window. Who, after the girls have fallen asleep, will turn the handle of the unlocked back door. When their parents return, they will find Olivia's bed empty. Their eldest daughter gone. Never to return. Until now. But is the woman who claims to be Olivia really all she seems? And is everything Caitlin said she saw that night really the whole truth? Their family have dreamt of this moment. But could Olivia's return be what destroys them.The absolutely gripping and page-turning new psychological thriller from bestselling author Dandy Smith, with a killer twist you won't see coming.",
  },
  {
    booktitle: 'Trending this week in one of your favorite genres',
    link: 'https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1605828061i/54737068._SY180_.jpg',
    genere: 'Fantasy',
    bookName: 'Local Woman Missing',
    bookAuthor: 'Mary Kubica',
    wantToRead: false,
    currentRead: false,
    read: false,
    details:
      'Shelby Tebow is the first to go missing. Not long after, Meredith Dickey and her six-year-old daughter, Delilah, vanish just blocks away from where Shelby was last seen, striking fear into their once-peaceful community. Are these incidents connected? After an elusive search that yields more questions than answers, the case eventually goes cold.',
  },
  {
    booktitle: 'Trending this week in one of your favorite genres',
    link: 'https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1713373397i/193781998._SY180_.jpg',
    genere: 'Thriller',
    bookName: 'The Husbands',
    bookAuthor: 'Kerryn Mayne',
    wantToRead: false,
    currentRead: false,
    read: false,
    details:
      'When Lauren returns home to her flat in London late one night, she is greeted at the door by her husband, Michael. There’s only one problem—she’s not married. She’s never seen this man before in her life. But according to her friends, her much-improved decor, and the photos on her phone, they’ve been together for years. As Lauren tries to puzzle out how she could be married to someone she can’t remember meeting, Michael goes to the attic to change a lightbulb and abruptly disappears. In his place, a new man emerges, and a new, slightly altered life re-forms around her. Realizing that her attic is creating an infinite supply of husbands, Lauren confronts the question: If swapping lives is as easy as changing a lightbulb, how do you know you’ve taken the right path? When do you stop trying to do better and start actually living?',
  },
  {
    booktitle: 'Trending this week in one of your favorite genres',
    link: 'https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1707929586i/195790841._SY180_.jpg',
    genere: 'Thriller',
    bookName: 'Lenny Marks Gets Away with Murder',
    bookAuthor: 'Lucy Score',
    wantToRead: false,
    currentRead: false,
    read: false,
    details:
      "The phone starts vibrating in my hand. It's my father. He never calls. Pulse racing in trepidation, I sit up in bed and answer. 'Caitlin,' he says. 'You need to come to the house. Right now. It's Olivia. She's back. On the night when Caitlin and Olivia's parents leave them to go to a dinner party both girls are full of excitement about being old enough to stay home alone What they don't see is the figure watching them through the open window. Who, after the girls have fallen asleep, will turn the handle of the unlocked back door. When their parents return, they will find Olivia's bed empty. Their eldest daughter gone. Never to return. Until now. But is the woman who claims to be Olivia really all she seems? And is everything Caitlin said she saw that night really the whole truth? Their family have dreamt of this moment. But could Olivia's return be what destroys them.The absolutely gripping and page-turning new psychological thriller from bestselling author Dandy Smith, with a killer twist you won't see coming.",
  },
  {
    booktitle: 'Trending this week in one of your favorite genres',
    link: 'https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1608577675i/56364569._SY180_.jpg',
    genere: 'Thriller',
    bookName:
      'Paul the Apostle: A Life from Beginning to End (Biographies of Christians)',
    bookAuthor: 'Hourly History',
    wantToRead: false,
    currentRead: false,
    read: false,
    details:
      'Discover the remarkable life of Paul the Apostle... Free BONUS Inside! It is a verifiable fact that the Apostle Paul was one of the most prolific writers of the New Testament, making him one of the founders of the Christian religion that we know today. Although he came on the scene after Jesus Christ, it could be argued that Saint Paul played the second biggest role in the history of Christianity.',
  },
  {
    booktitle: 'Trending this week in one of your favorite genres',
    link: 'https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1709243427i/58320317._SY180_.jpg',
    genere: 'Thriller',
    bookName: 'The Alpha (The Lycans, #4)',
    bookAuthor: 'Jenika Snow',
    wantToRead: false,
    currentRead: false,
    read: false,
    details:
      'I’d never felt like I was missing anything in my life, not until my only friend left to start a journey to find out her own history. It had been clear in the ugliest way that I relied on her company too much over the years. I needed to make my own path, create my own story. But then one video call changed my entire life, and I was thrown into a new world where creatures that had only ever been in fiction and movies were now very much real.',
  },
  {
    booktitle: 'Trending this week in one of your favorite genres',
    link: 'https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1697984764i/199551453._SY180_.jpg',
    genere: 'Thriller',
    bookName: 'The Wrong Daughter',
    bookAuthor: 'Dandy Smith',
    wantToRead: false,
    currentRead: false,
    read: false,
    details:
      "The phone starts vibrating in my hand. It's my father. He never calls. Pulse racing in trepidation, I sit up in bed and answer. 'Caitlin,' he says. 'You need to come to the house. Right now. It's Olivia. She's back. On the night when Caitlin and Olivia's parents leave them to go to a dinner party both girls are full of excitement about being old enough to stay home alone What they don't see is the figure watching them through the open window. Who, after the girls have fallen asleep, will turn the handle of the unlocked back door. When their parents return, they will find Olivia's bed empty. Their eldest daughter gone. Never to return. Until now. But is the woman who claims to be Olivia really all she seems? And is everything Caitlin said she saw that night really the whole truth? Their family have dreamt of this moment. But could Olivia's return be what destroys them.The absolutely gripping and page-turning new psychological thriller from bestselling author Dandy Smith, with a killer twist you won't see coming.",
  },
  {
    booktitle: 'Trending this week in one of your favorite genres',
    link: 'https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1605828061i/54737068._SY180_.jpg',
    genere: 'Fantasy',
    bookName: 'Local Woman Missing',
    bookAuthor: 'Mary Kubica',
    wantToRead: false,
    currentRead: false,
    read: false,
    details:
      'Shelby Tebow is the first to go missing. Not long after, Meredith Dickey and her six-year-old daughter, Delilah, vanish just blocks away from where Shelby was last seen, striking fear into their once-peaceful community. Are these incidents connected? After an elusive search that yields more questions than answers, the case eventually goes cold.',
  },
  {
    booktitle: 'Trending this week in one of your favorite genres',
    link: 'https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1713373397i/193781998._SY180_.jpg',
    genere: 'Thriller',
    bookName: 'The Husbands',
    bookAuthor: 'Kerryn Mayne',
    wantToRead: false,
    currentRead: false,
    read: false,
    details:
      'When Lauren returns home to her flat in London late one night, she is greeted at the door by her husband, Michael. There’s only one problem—she’s not married. She’s never seen this man before in her life. But according to her friends, her much-improved decor, and the photos on her phone, they’ve been together for years. As Lauren tries to puzzle out how she could be married to someone she can’t remember meeting, Michael goes to the attic to change a lightbulb and abruptly disappears. In his place, a new man emerges, and a new, slightly altered life re-forms around her. Realizing that her attic is creating an infinite supply of husbands, Lauren confronts the question: If swapping lives is as easy as changing a lightbulb, how do you know you’ve taken the right path? When do you stop trying to do better and start actually living?',
  },
  {
    booktitle: 'Trending this week in one of your favorite genres',
    link: 'https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1707929586i/195790841._SY180_.jpg',
    genere: 'Thriller',
    bookName: 'Lenny Marks Gets Away with Murder',
    bookAuthor: 'Lucy Score',
    wantToRead: false,
    currentRead: false,
    read: false,
    details:
      "The phone starts vibrating in my hand. It's my father. He never calls. Pulse racing in trepidation, I sit up in bed and answer. 'Caitlin,' he says. 'You need to come to the house. Right now. It's Olivia. She's back. On the night when Caitlin and Olivia's parents leave them to go to a dinner party both girls are full of excitement about being old enough to stay home alone What they don't see is the figure watching them through the open window. Who, after the girls have fallen asleep, will turn the handle of the unlocked back door. When their parents return, they will find Olivia's bed empty. Their eldest daughter gone. Never to return. Until now. But is the woman who claims to be Olivia really all she seems? And is everything Caitlin said she saw that night really the whole truth? Their family have dreamt of this moment. But could Olivia's return be what destroys them.The absolutely gripping and page-turning new psychological thriller from bestselling author Dandy Smith, with a killer twist you won't see coming.",
  },
  {
    booktitle: 'Trending this week in one of your favorite genres',
    link: 'https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1608577675i/56364569._SY180_.jpg',
    genere: 'Thriller',
    bookName:
      'Paul the Apostle: A Life from Beginning to End (Biographies of Christians)',
    bookAuthor: 'Hourly History',
    wantToRead: false,
    currentRead: false,
    read: false,
    details:
      'Discover the remarkable life of Paul the Apostle... Free BONUS Inside! It is a verifiable fact that the Apostle Paul was one of the most prolific writers of the New Testament, making him one of the founders of the Christian religion that we know today. Although he came on the scene after Jesus Christ, it could be argued that Saint Paul played the second biggest role in the history of Christianity.',
  },
  {
    booktitle: 'Trending this week in one of your favorite genres',
    link: 'https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1709243427i/58320317._SY180_.jpg',
    genere: 'Thriller',
    bookName: 'The Alpha (The Lycans, #4)',
    bookAuthor: 'Jenika Snow',
    wantToRead: false,
    currentRead: false,
    read: false,
    details:
      'I’d never felt like I was missing anything in my life, not until my only friend left to start a journey to find out her own history. It had been clear in the ugliest way that I relied on her company too much over the years. I needed to make my own path, create my own story. But then one video call changed my entire life, and I was thrown into a new world where creatures that had only ever been in fiction and movies were now very much real.',
  },
];
