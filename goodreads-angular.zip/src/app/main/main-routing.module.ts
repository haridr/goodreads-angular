import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { HomeComponent } from './components/home/home.component';
import { MybooksComponent } from './components/mybooks/MybooksComponent';
import { BookviewComponent } from './components/bookview/bookview.component';

const routes: Routes = [
  { path: '', redirectTo: '/main/home', pathMatch: 'full' },
  {
    path: 'main',
    component: LandingPageComponent,
    children: [
      { path: 'home', component: HomeComponent },
      { path: 'mybooks', component: MybooksComponent },
      { path: 'bookview', component: BookviewComponent },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MainRoutingModule {}
