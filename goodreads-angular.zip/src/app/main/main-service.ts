import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { Injectable } from '@angular/core';
@Injectable({ providedIn: 'root' })
export class mainService {
  constructor() {}

  private subject = new BehaviorSubject('');
  currentMessage = this.subject.asObservable();

  sendMessage(message: any) {
    this.subject.next(message);
  }
}
