import { Component, HostListener, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import {
  Observable,
  combineLatest,
  debounceTime,
  distinctUntilChanged,
  map,
  of,
  startWith,
} from 'rxjs';
import { Book, bookData } from '../components/books-file';
import { Router } from '@angular/router';
import { mainService } from '../main-service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  username: string | null = 'USERNAMe';
  public innerWidth: any;
  display = 'desktop';
  searchEnabled: boolean = false;
  openableMenu = false;
  searchOpened = false;
  searchOpened1 = false;

  allbooks$: Observable<Book[]>;

  filteredBooks$: Observable<Book[]>;
  filter: FormControl;
  filter$: Observable<string>;

  constructor(private router: Router, private mainservice: mainService) {
    console.log(localStorage.getItem('username'));
    let user = localStorage.getItem('username');

    if (user != null) {
      this.username = user.toUpperCase();
    }
    this.allbooks$ = of(bookData);

    this.filter = new FormControl('');
    this.filter$ = this.filter.valueChanges.pipe(startWith(''));

    this.filteredBooks$ = combineLatest(this.allbooks$, this.filter$).pipe(
      debounceTime(500),
      distinctUntilChanged(),
      map(([allbooks, filterString]) =>
        allbooks.filter(
          (country) =>
            country.bookName.toLowerCase().includes(filterString) ||
            country.bookAuthor.toLowerCase().includes(filterString) ||
            country.booktitle.toLowerCase().includes(filterString)
        )
      )
    );

    if (this.router.url.includes('bookview')) {
      this.searchOpened1 = false;
      this.searchEnabled = false;
    }
  }

  clickedOutside(): void {
    setTimeout(() => {
      this.searchOpened = false;
      this.searchOpened1 = false;
    }, 4000);
  }

  focusFunction() {
    this.searchOpened = true;
  }

  focusFunction1() {
    if (!this.router.url.includes('bookview')) {
      this.searchOpened1 = true;
    }
  }

  focusOutFunction() {
    setTimeout(() => {
      this.searchOpened = false;
      this.searchOpened1 = false;
    }, 100);
  }

  ngOnInit(): void {
    //for screen size
    this.onResize();
  }

  @HostListener('window:resize', ['$event'])
  onResize() {
    this.innerWidth = window.innerWidth;

    if (this.innerWidth < 1200 && this.innerWidth > 767) {
      this.display = 'tablet';
      this.searchEnabled = false;
    } else if (this.innerWidth < 767) {
      this.display = 'mobile';
    } else {
      this.display = 'desktop';
      this.searchEnabled = false;
    }
  }

  searchEnable() {
    if (!this.router.url.includes('bookview')) {
      this.searchEnabled = !this.searchEnabled;
    }
    this.searchOpened = false;
    this.searchOpened1 = false;
  }

  openMenu() {
    this.openableMenu = !this.openableMenu;
  }

  booknavigate(book: any) {
    setTimeout(() => {
      this.mainservice.sendMessage(book);
      this.router.navigate(['/main/bookview']);
    }, 200);
  }

  signOut() {
    localStorage.clear();
    this.router.navigate(['/login'], { replaceUrl: true });
  }
}
